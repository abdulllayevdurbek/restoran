'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const mison = require('./mison');
const PORT = +process.env.PORT || 3000;
const SECRET = process.env.SECRET || 'dev-secret-change-me';
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const PUB = path.join(__dirname, 'public');
const TZ = 'Asia/Tashkent';

/* ================= SAQLASH (Postgres yoki fayl) ================= */
let store;
async function initStore() {
  if (process.env.DATABASE_URL) {
    const { Pool } = require('pg');
    const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'off' ? false : { rejectUnauthorized: false } });
    await pool.query(`create table if not exists tenants(slug text primary key, data jsonb not null);
      create table if not exists orders(slug text, id int, data jsonb not null, primary key(slug,id));
      create table if not exists customers(slug text, phone text, data jsonb not null, primary key(slug,phone));`);
    const q = async (s, a) => (await pool.query(s, a)).rows;
    store = {
      getT: async s => (await q('select data from tenants where slug=$1', [s]))[0]?.data,
      putT: (s, d) => q('insert into tenants values($1,$2) on conflict(slug) do update set data=$2', [s, d]),
      listT: async () => (await q('select slug,data from tenants order by slug')).map(r => ({ slug: r.slug, name: r.data.cfg.name })),
      listO: async s => (await q('select data from orders where slug=$1 order by id desc limit 500', [s])).map(r => r.data),
      getO: async (s, id) => (await q('select data from orders where slug=$1 and id=$2', [s, id]))[0]?.data,
      addO: async (s, o) => {
        const r = await q('insert into orders select $1, coalesce(max(id),0)+1, $2::jsonb from orders where slug=$1 returning id', [s, o]);
        o.id = r[0].id; await q('update orders set data=$3 where slug=$1 and id=$2', [s, o.id, o]); return o;
      },
      putO: (s, o) => q('update orders set data=$3 where slug=$1 and id=$2', [s, o.id, o]),
      getC: async (s, p) => (await q('select data from customers where slug=$1 and phone=$2', [s, p]))[0]?.data,
      putC: (s, p, d) => q('insert into customers values($1,$2,$3) on conflict(slug,phone) do update set data=$3', [s, p, d]),
    };
    console.log('Baza: PostgreSQL');
  } else {
    const file = path.join(__dirname, 'data', 'db.json');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    let db = { t: {}, o: {}, c: {} };
    try { db = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {}
    let timer; const flush = () => { clearTimeout(timer); timer = setTimeout(() => fs.writeFileSync(file, JSON.stringify(db)), 200); };
    store = {
      getT: async s => db.t[s],
      putT: async (s, d) => { db.t[s] = d; flush(); },
      listT: async () => Object.entries(db.t).map(([slug, d]) => ({ slug, name: d.cfg.name })),
      listO: async s => (db.o[s] || []).slice().reverse().slice(0, 500),
      getO: async (s, id) => (db.o[s] || []).find(o => o.id === id),
      addO: async (s, o) => { const a = db.o[s] || (db.o[s] = []); o.id = a.reduce((m, x) => Math.max(m, x.id), 0) + 1; a.push(o); flush(); return o; },
      putO: async (s, o) => { const a = db.o[s] || []; const i = a.findIndex(x => x.id === o.id); if (i >= 0) a[i] = o; flush(); },
      getC: async (s, p) => db.c[s + '|' + p],
      putC: async (s, p, d) => { db.c[s + '|' + p] = d; flush(); },
    };
    console.log('Baza: fayl (faqat sinov uchun, DATABASE_URL kiritilmagan)');
  }
}

/* ================= YORDAMCHILAR ================= */
const b64 = b => Buffer.from(b).toString('base64url');
const sign = (p, days) => { const body = b64(JSON.stringify({ ...p, exp: Date.now() + days * 864e5 })); return body + '.' + crypto.createHmac('sha256', SECRET).update(body).digest('base64url'); };
function verify(tok) {
  if (!tok) return null; const [body, sig] = tok.split('.'); if (!body || !sig) return null;
  const ok = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  if (sig.length !== ok.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(ok))) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch (e) { return null; }
}
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const checkPw = (pw, h) => { const [s] = h.split(':'); const x = hashPw(pw, s); return x.length === h.length && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(h)); };
const KEY = crypto.createHash('sha256').update(SECRET).digest();
const enc = t => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv), d = Buffer.concat([c.update(t, 'utf8'), c.final()]); return [iv, c.getAuthTag(), d].map(x => x.toString('base64')).join('.'); };
const dec = t => { try { const [iv, tag, d] = t.split('.').map(x => Buffer.from(x, 'base64')), c = crypto.createDecipheriv('aes-256-gcm', KEY, iv); c.setAuthTag(tag); return Buffer.concat([c.update(d), c.final()]).toString('utf8'); } catch (e) { return ''; } };
const hits = new Map();
function limited(key, max, ms) { const n = Date.now(), a = (hits.get(key) || []).filter(t => n - t < ms); a.push(n); hits.set(key, a); return a.length > max; }
const nowHM = () => new Date().toLocaleTimeString('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit' });
function isOpen(cfg) { const m = s => { const [h, mi] = (s || '0:0').split(':'); return +h * 60 + +mi; }, [h, mi] = nowHM().split(':'), n = +h * 60 + +mi, a = m(cfg.from), b = m(cfg.to); return a <= b ? n >= a && n < b : n >= a || n < b; }
const DEFAULT_CFG = { name: 'Restoran', color: '#1fa94b', phone: '', tg: '', logo: '', mison: '', from: '09:00', to: '23:00', fee: 10000, min: 30000, bonus: 5, pay: { cash: 1, card: 1, payme: 0, click: 0 }, branches: [{ n: 'Asosiy filial', a: '' }], promos: [] };
const DEFAULT_BN = [{ t: 'Xush kelibsiz', s: 'Birinchi buyurtmaga chegirma', c: '#1fa94b', e: '🍽️' }];
const PAYN = { cash: 'Naqd pul', card: 'Karta (kuryerga)', payme: 'Payme', click: 'Click' };
const pubCfg = c => { const { mison, ...r } = c; return r; };
const panelCfg = c => ({ ...c, mison: c.mison ? '••••' : '' });

async function sendSms(phone, text) {
  console.log('[SMS]', phone, text);
  const { ESKIZ_EMAIL: em, ESKIZ_PASSWORD: pw } = process.env;
  if (!em || !pw) return;
  // Eskiz.uz (tekshirilmagan: akkauntingiz hujjatiga qarab sozlang)
  const a = await (await fetch('https://notify.eskiz.uz/api/auth/login', { method: 'POST', body: new URLSearchParams({ email: em, password: pw }) })).json();
  const f = new FormData(); f.append('mobile_phone', phone); f.append('message', text); f.append('from', process.env.ESKIZ_FROM || '4546');
  await fetch('https://notify.eskiz.uz/api/message/sms/send', { method: 'POST', headers: { Authorization: 'Bearer ' + a.data.token }, body: f });
}
const otps = new Map();

function priceLine(menu, l) {
  for (const c of menu) for (const p of c.i) if (p.n === l.n && p.on) {
    let u = +p.p; const v = (p.v || []).find(o => o.n === l.v); if (v) u += +v.p;
    const xs = []; (l.x || []).forEach(n => { const x = (p.x || []).find(o => o.n === n); if (x) { u += +x.p; xs.push(x.n); } });
    return { n: p.n, o: [v ? v.n : '', ...xs].filter(Boolean).join(', '), p: u, q: Math.min(50, Math.max(1, l.q | 0)) };
  }
  return null;
}

/* ================= HTTP ================= */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
const fail = (res, code, msg) => send(res, code, { error: msg });
function body(req) { return new Promise((ok, no) => { let n = 0; const a = []; req.on('data', c => { n += c.length; if (n > 12e6) { no(Object.assign(new Error('Juda katta'), { status: 413 })); req.destroy(); } else a.push(c); }); req.on('end', () => { try { ok(a.length ? JSON.parse(Buffer.concat(a)) : {}); } catch (e) { no(Object.assign(new Error('JSON xato'), { status: 400 })); } }); }); }
const tokenOf = req => (req.headers.authorization || '').replace(/^Bearer /, '');
const slugOk = s => /^[a-z0-9-]{2,40}$/.test(s || '');

async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  let r;
  if (m === 'GET' && (r = p.match(/^\/api\/public\/([\w-]+)$/))) {
    const t = await store.getT(r[1]); if (!t) return fail(res, 404, 'Restoran topilmadi');
    return send(res, 200, { cfg: pubCfg(t.cfg), menu: t.menu, bn: t.bn, open: isOpen(t.cfg) });
  }
  if (m === 'POST' && p === '/api/auth/request') {
    const b = await body(req), slug = b.slug, ph = String(b.phone || '').replace(/\D/g, '');
    if (!/^998\d{9}$/.test(ph) || !(await store.getT(slug))) return fail(res, 400, 'Telefon raqam noto‘g‘ri');
    if (limited('otp:' + ph, 5, 600000) || limited('otpip:' + req.socket.remoteAddress, 30, 600000)) return fail(res, 429, 'Juda ko‘p urinish, keyinroq qayta urining');
    const code = String(crypto.randomInt(1000, 10000));
    otps.set(slug + ph, { h: crypto.createHash('sha256').update(code + SECRET).digest('hex'), exp: Date.now() + 300000, tries: 0 });
    await sendSms(ph, 'Tasdiqlash kodi: ' + code);
    return send(res, 200, { ok: true, dev: process.env.SMS_DEV === '1' ? code : undefined });
  }
  if (m === 'POST' && p === '/api/auth/verify') {
    const b = await body(req), ph = String(b.phone || '').replace(/\D/g, ''), o = otps.get(b.slug + ph);
    if (!o || o.exp < Date.now() || ++o.tries > 5) return fail(res, 400, 'Kod eskirgan, qayta so‘rang');
    if (crypto.createHash('sha256').update(String(b.code) + SECRET).digest('hex') !== o.h) return fail(res, 400, 'Kod noto‘g‘ri');
    otps.delete(b.slug + ph);
    let c = await store.getC(b.slug, ph); if (!c) { c = { phone: ph, bonus: 0 }; await store.putC(b.slug, ph, c); }
    return send(res, 200, { token: sign({ r: b.slug, ph, role: 'cu' }, 30), user: c });
  }
  const cu = (() => { const t = verify(tokenOf(req)); return t && t.role === 'cu' ? t : null; })();
  if (m === 'GET' && p === '/api/me') {
    if (!cu) return fail(res, 401, 'Kirish kerak');
    const c = (await store.getC(cu.r, cu.ph)) || { phone: cu.ph, bonus: 0 };
    return send(res, 200, { user: c, orders: (await store.listO(cu.r)).filter(o => o.ph === cu.ph) });
  }
  if (m === 'POST' && p === '/api/orders') {
    if (!cu) return fail(res, 401, 'Kirish kerak');
    const b = await body(req), t = await store.getT(cu.r), cfg = t.cfg;
    if (!isOpen(cfg)) return fail(res, 400, 'Hozir yopiq');
    const li = (b.lines || []).slice(0, 60).map(l => priceLine(t.menu, l));
    if (!li.length || li.includes(null)) return fail(res, 400, 'Savatdagi taom topilmadi yoki tugagan');
    const type = b.type === 'pick' ? 'pick' : 'del';
    if (type === 'del' && !String(b.addr || '').trim()) return fail(res, 400, 'Manzilni kiriting');
    if (type === 'pick' && !cfg.branches[+b.br]) return fail(res, 400, 'Filialni tanlang');
    if (!cfg.pay[b.pay]) return fail(res, 400, 'To‘lov usuli mavjud emas');
    const sub = li.reduce((s, l) => s + l.p * l.q, 0);
    if (sub < cfg.min) return fail(res, 400, 'Minimal buyurtma: ' + cfg.min);
    const promo = (cfg.promos || []).find(x => x.c.toUpperCase() === String(b.promo || '').trim().toUpperCase());
    const disc = promo ? Math.floor(sub * promo.p / 100) : 0, fee = type === 'del' ? +cfg.fee : 0;
    const c = (await store.getC(cu.r, cu.ph)) || { phone: cu.ph, bonus: 0 };
    const bu = b.useB ? Math.min(c.bonus, sub - disc) : 0;
    const o = await store.addO(cu.r, { st: 0, t: sub - disc + fee - bu, sub, disc, fee, bu, time: nowHM(), created: new Date().toISOString(), li, ph: cu.ph, type, addr: String(b.addr || '').slice(0, 300), br: +b.br || 0, pay: PAYN[b.pay], payKey: b.pay, note: String(b.note || '').slice(0, 300) });
    if (bu) { c.bonus -= bu; await store.putC(cu.r, cu.ph, c); }
    mison.pushOrder(cfg, cfg.mison ? dec(cfg.mison) : '', o).catch(e => console.log('Mison pushOrder:', e.message));
    return send(res, 200, { order: o, user: c });
  }
  /* ---- panel ---- */
  if (m === 'POST' && p === '/api/panel/login') {
    const b = await body(req);
    if (limited('pl:' + req.socket.remoteAddress, 10, 600000)) return fail(res, 429, 'Juda ko‘p urinish');
    const t = await store.getT(b.slug);
    if (!t || !checkPw(String(b.password || ''), t.pw)) return fail(res, 401, 'Restoran yoki parol noto‘g‘ri');
    return send(res, 200, { token: sign({ r: b.slug, role: 'panel' }, 7) });
  }
  const pn = (() => { const t = verify(tokenOf(req)); return t && t.role === 'panel' ? t : null; })();
  if (p.startsWith('/api/panel/')) {
    if (!pn) return fail(res, 401, 'Qayta kiring');
    const t = await store.getT(pn.r);
    if (m === 'GET' && p === '/api/panel/data') return send(res, 200, { cfg: panelCfg(t.cfg), menu: t.menu, bn: t.bn });
    if (m === 'PUT' && p === '/api/panel/data') {
      const b = await body(req), c = { ...DEFAULT_CFG, ...(b.cfg || {}) };
      if (!c.mison || c.mison === '••••') c.mison = c.mison === '' ? '' : t.cfg.mison || ''; else c.mison = enc(c.mison);
      c.pay = { ...DEFAULT_CFG.pay, ...(c.pay || {}) };
      if (!Array.isArray(b.menu) || !Array.isArray(b.bn)) return fail(res, 400, 'Ma’lumot noto‘g‘ri');
      await store.putT(pn.r, { ...t, cfg: c, menu: b.menu, bn: b.bn });
      return send(res, 200, { ok: true });
    }
    if (m === 'GET' && p === '/api/panel/orders') return send(res, 200, { orders: await store.listO(pn.r) });
    if (m === 'PATCH' && (r = p.match(/^\/api\/panel\/orders\/(\d+)$/))) {
      const b = await body(req), o = await store.getO(pn.r, +r[1]); if (!o) return fail(res, 404, 'Topilmadi');
      const c = o.ph ? ((await store.getC(pn.r, o.ph)) || { phone: o.ph, bonus: 0 }) : null;
      if (b.action === 'cancel' && o.st >= 0 && o.st < 3) { o.st = -1; if (c && o.bu) { c.bonus += o.bu; await store.putC(pn.r, o.ph, c); } }
      else if (b.action === 'next' && o.st >= 0 && o.st < 3) {
        o.st = o.st === 1 && o.type === 'pick' ? 3 : o.st + 1;
        if (o.st === 3 && c && !o.credited) { o.credited = true; c.bonus += Math.floor(o.t * t.cfg.bonus / 100); await store.putC(pn.r, o.ph, c); }
      } else return fail(res, 400, 'Amal mumkin emas');
      await store.putO(pn.r, o); return send(res, 200, { order: o });
    }
    if (m === 'POST' && p === '/api/panel/mison/sync') {
      const menu = await mison.fetchMenu(t.cfg, t.cfg.mison ? dec(t.cfg.mison) : '');
      await store.putT(pn.r, { ...t, menu }); return send(res, 200, { menu });
    }
    return fail(res, 404, 'Topilmadi');
  }
  /* ---- admin (siz uchun) ---- */
  if (p.startsWith('/api/admin/')) {
    if (!ADMIN_KEY || req.headers['x-admin-key'] !== ADMIN_KEY) return fail(res, 401, 'Admin kaliti noto‘g‘ri');
    if (m === 'GET' && p === '/api/admin/tenants') return send(res, 200, { tenants: await store.listT() });
    if (m === 'POST' && p === '/api/admin/tenants') {
      const b = await body(req);
      if (!slugOk(b.slug) || !b.name || String(b.password || '').length < 6) return fail(res, 400, 'slug (a-z,0-9,-), nom va parol (6+) kerak');
      if (await store.getT(b.slug)) return fail(res, 409, 'Bu slug band');
      await store.putT(b.slug, { cfg: { ...DEFAULT_CFG, name: b.name }, menu: [], bn: DEFAULT_BN, pw: hashPw(b.password) });
      return send(res, 200, { ok: true, customerUrl: '/r/' + b.slug, panelUrl: '/panel' });
    }
    if (m === 'POST' && p === '/api/admin/password') {
      const b = await body(req), t = await store.getT(b.slug); if (!t || String(b.password || '').length < 6) return fail(res, 400, 'Xato');
      t.pw = hashPw(b.password); await store.putT(b.slug, t); return send(res, 200, { ok: true });
    }
  }
  return fail(res, 404, 'Topilmadi');
}

function serve(res, file) {
  fs.readFile(file, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Topilmadi'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' }); res.end(d);
  });
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x'), p = url.pathname;
    if (p === '/healthz') return send(res, 200, { ok: true });
    if (p.startsWith('/api/')) return await api(req, res, url);
    if (/^\/r\/[\w-]+\/?$/.test(p)) return serve(res, path.join(PUB, 'index.html'));
    if (p === '/panel') return serve(res, path.join(PUB, 'panel.html'));
    if (p === '/admin') return serve(res, path.join(PUB, 'admin.html'));
    if (p === '/') return serve(res, path.join(PUB, 'home.html'));
    const f = path.normalize(path.join(PUB, p));
    if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
    serve(res, f);
  } catch (e) { console.error(e); fail(res, e.status || 500, e.status ? e.message : 'Server xatosi'); }
});
initStore().then(() => server.listen(PORT, () => console.log('Server ishga tushdi: port ' + PORT))).catch(e => { console.error('Baza xatosi:', e); process.exit(1); });
