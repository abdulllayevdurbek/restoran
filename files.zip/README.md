# Restoran buyurtma tizimi (EVOS uslubida)

Bitta server ko‘p restoranga xizmat qiladi. Har bir restoran uchun:
- Mijoz ilovasi: `https://SIZNING-SAYT.onrender.com/r/<identifikator>`
- Restoran paneli: `https://SIZNING-SAYT.onrender.com/panel`
- Siz uchun admin sahifa: `https://SIZNING-SAYT.onrender.com/admin`

## Render ga joylash
1. Bu papkani GitHub ga yuklang (yangi repozitoriy).
2. neon.tech da bepul baza oching va **Connection string** ni nusxalang.
3. render.com → New → Blueprint (yoki Web Service) → GitHub repozitoriyni tanlang.
4. Environment bo‘limida:
   - `DATABASE_URL` = Neon ulanish satri
   - `ADMIN_KEY` = o‘zingiz o‘ylab topgan uzun maxfiy so‘z
   - `SECRET` = uzun tasodifiy matn (render.yaml o‘zi yaratadi). **Keyin o‘zgartirmang**, aks holda saqlangan Mison kalitlari o‘qilmay qoladi.
   - `SMS_DEV=1` faqat sinov uchun: SMS kod ekranda ko‘rinadi. Haqiqiy ishga tushirishdan oldin o‘chiring va Eskiz ma’lumotlarini kiriting (`ESKIZ_EMAIL`, `ESKIZ_PASSWORD`).
5. Deploy tugagach `/admin` ga kiring, ADMIN_KEY ni yozing va restoran qo‘shing.
6. Restoran egasi `/panel` ga identifikator va parol bilan kiradi, menyu va sozlamalarni to‘ldiradi.

## Hali tugallanmagan qismlar
- **Mison:** `mison.js` da joy tayyor. API hujjati kelgach `fetchMenu` va `pushOrder` to‘ldiriladi.
- **Payme/Click:** hozir to‘lov usuli faqat buyurtmaga yoziladi, onlayn to‘lov yo‘q.
- **SMS (Eskiz):** kod yozilgan, lekin sizning akkauntingiz bilan sinab ko‘rilmagan.
- **Rasmlar** bazada saqlanadi (kichraytirilgan). Ko‘p restoran bo‘lganda Cloudflare R2 ga o‘tish kerak.
- Render bepul rejasi 15 daqiqa harakatsizlikdan keyin uxlaydi (birinchi so‘rov sekin). Haqiqiy mijozlar uchun pullik rejaga o‘ting.
- Mijoz ilovasi hozir veb sahifa. Play Market/App Store uchun keyin Flutter (yoki WebView) o‘ram qilinadi.
