'use strict';
// Mison integratsiyasi uchun joy.
// Mison API hujjati kelgach, shu fayldagi fetchMenu ni to‘ldiramiz.
// U restoranning Mison kaliti (cfg.mison, serverda shifrlangan) bilan menyuni olib,
// QUYIDAGI formatda qaytarishi kerak:
//   [{ c:'Kategoriya', i:[{ n:'Nomi', p:42000, e:'🌯', w:320, k:640, d:'Tarkibi', b:'Hit',
//      ph:'', on:1, v:[{n:'Katta',p:12000}], x:[{n:'Pishloq',p:5000}] }] }]
async function fetchMenu(/* cfg, apiKey */) {
  const e = new Error('Mison API hali sozlanmagan: API hujjati kerak (mison.js ni to‘ldiring).');
  e.status = 501;
  throw e;
}
// Buyurtmani Mison kassasiga yuborish uchun (hujjat kelgach):
async function pushOrder(/* cfg, apiKey, order */) { return null; }
module.exports = { fetchMenu, pushOrder };
